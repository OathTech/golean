package main
import ("os"; "sync")
func main() {
 print("prefix\x00\x01\r\n")
 switch os.Args[1] {
 case "plain": panic("payload\x00\x01\t\r\nsecond")
 case "repanic": defer func(){_ = recover(); panic("replacement")}(); panic("payload\x00\x01\t\r\nsecond")
 case "fatal": var m sync.Mutex; defer m.Unlock(); panic("original")
 case "invalid": panic(string([]byte{0xff}))
 }
}
