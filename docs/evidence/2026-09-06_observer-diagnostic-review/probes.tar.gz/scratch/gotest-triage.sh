set -uo pipefail
one_line() {
  local value="$1"
  value="${value//$'\t'/ }"
  value="${value//$'\r'/\\r}"
  value="${value//$'\n'/\\n}"
  printf '%s' "$value"
}
probe() {
  # Expected Go-side output per the testdir rule: <name>.out or empty.
  local out_file="${src%.go}.out"

  # --- Go oracle -------------------------------------------------------
  # Same env pins as scripts/diff-coverage's go_run_oracle: GOPATH mode,
  # modern panic(nil) semantics, shared build cache. Since stdlib slice 3
  # stdout and stderr are captured SEPARATELY (the `output` observation is
  # the program's fd-2 prefix — print/println — recovered fail-closed by
  # the harness's --split-stderr mode, exactly as scripts/diff-coverage
  # does). The .out comparison reads concatenated descriptor BYTES, while
  # status classification reads stderr alone. Bash never carries raw bytes.
  local go_out go_rc
  (cd "$dir" && timeout "$GO_TIMEOUT" env GO111MODULE=off GOFLAGS= GODEBUG=panicnil=0 GOCACHE="$GO_BUILD_CACHE" go run main.go > oracle.stdout 2> oracle.stderr)
  go_rc=$?
  go_out="stdout=$("$HARNESS_BIN" --quote-file "$dir/oracle.stdout") stderr=$("$HARNESS_BIN" --quote-file "$dir/oracle.stderr")"

  local go_status="" go_obs="" go_msg="" output_flag="" out_lit split_rc=0
  if [[ "$go_rc" -eq 124 ]]; then
    printf 'INFRA\t%s\t%s\n' "$rel" "go run timed out after ${GO_TIMEOUT}s"
    return
  elif [[ "$go_rc" -eq 0 ]]; then
    # Pinned cmd/internal/testdir/testdir_test.go checkExpectedOutput:
    # normalize CRLF on actual bytes, then exact equality with .out (or
    # empty when absent). No NUL deletion or trailing-newline trimming.
    if ! python3 - "$dir/oracle.stdout" "$dir/oracle.stderr" "$out_file" <<'PY'
from pathlib import Path
import sys
stdout, stderr, expected = map(Path, sys.argv[1:])
actual = (stdout.read_bytes() + stderr.read_bytes()).replace(b'\r\n', b'\n')
want = expected.read_bytes() if expected.exists() else b''
raise SystemExit(0 if actual == want else 1)
PY
    then
      # The pinned toolchain itself deviates from the suite's expectation
      # — environment- or flag-dependent test; not a machine verdict.
      printf 'INFRA\t%s\t%s\n' "$rel" "go output != expected .out on the pinned toolchain: $(one_line "${go_out:0:200}")"
      return
    fi
    go_status="ok"
    if [[ -s "$dir/oracle.stdout" ]]; then
      # fd 1 is outside the machine's observable (os.Stdout is gate G7,
      # not this slice): the row is status-compared with the flag kept.
      output_flag="output-uncompared($(wc -c < "$dir/oracle.stdout")B on stdout: no stdout observable — G7); "
    fi
  elif [[ "$go_rc" -ne 1 ]]; then
    printf 'INFRA\t%s\t%s\n' "$rel" "go run exited $go_rc without a runtime verdict: $(one_line "${go_out:0:200}")"
    return
  elif grep -aqF -- 'fatal error: all goroutines are asleep - deadlock!' "$dir/oracle.stderr"; then
    go_status="deadlock"
    go_obs='{"message":"all goroutines are asleep - deadlock!","schema":"golean-observation-v1","status":"deadlock"}'
  elif grep -aqF -- 'panic:' "$dir/oracle.stderr"; then
    go_status="panic"
    if ! go_msg="$("$HARNESS_BIN" --abort-message "$dir/oracle.stderr" --expected-status panic 2>"$dir/oracle.message.err")"; then
      printf 'INFRA\t%s\t%s\n' "$rel" "oracle panic message refused: $(cat "$dir/oracle.message.err")"; return
    fi
    go_obs="{\"message\":$go_msg,\"schema\":\"golean-observation-v1\",\"status\":\"panic\"}"
  elif grep -aqF -- 'fatal error: ' "$dir/oracle.stderr"; then
    go_status="fatal"
    if ! go_msg="$("$HARNESS_BIN" --abort-message "$dir/oracle.stderr" --expected-status fatal 2>"$dir/oracle.message.err")"; then
      printf 'INFRA\t%s\t%s\n' "$rel" "oracle fatal message refused: $(cat "$dir/oracle.message.err")"; return
    fi
    go_obs="{\"message\":$go_msg,\"schema\":\"golean-observation-v1\",\"status\":\"fatal\"}"
  else
    # Compile error, unsatisfied build constraints, os.Exit(1), ... — no
    # comparable runtime verdict from the oracle side.
    printf 'INFRA\t%s\t%s\n' "$rel" "go run exited $go_rc without panic/fatal: $(one_line "${go_out:0:200}")"
    return
  fi
  # The `output` field: the program's fd-2 prefix (stderr split by the
  # harness under the status' rule); an ambiguous split is an INFRA row —
  # the observation cannot be assembled, so nothing is compared.
  out_lit="$("$HARNESS_BIN" --split-stderr "$dir/oracle.stderr" --expected-status "$go_status" 2>"$dir/oracle.split.err")" || split_rc=$?
  if [[ "$split_rc" -ne 0 ]]; then
    printf 'INFRA\t%s\t%s\n' "$rel" "oracle stderr split failed (harness exit $split_rc): $(one_line "$(cat "$dir/oracle.split.err")")"
    return
  fi
  if [[ "$go_status" == "ok" ]]; then
    go_obs="{\"output\":$out_lit,\"schema\":\"golean-observation-v1\",\"status\":\"ok\",\"values\":[]}"
  else
    go_obs="{\"output\":$out_lit,${go_obs#\{}"
  fi



printf "%s" "$go_obs"
}
probe
