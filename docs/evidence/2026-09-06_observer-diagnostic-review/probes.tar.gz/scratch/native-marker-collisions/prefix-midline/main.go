package main
func main(){print("prefix fatal error: user output\n");panic("original")}
