package main
func main(){panic("original\nfatal error: sync: unlock of unlocked mutex")}
