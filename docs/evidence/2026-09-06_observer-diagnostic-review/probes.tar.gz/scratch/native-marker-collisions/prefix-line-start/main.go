package main
func main(){print("fatal error: user output\n");panic("original")}
