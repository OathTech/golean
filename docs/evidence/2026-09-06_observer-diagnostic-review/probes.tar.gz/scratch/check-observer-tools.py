"""Byte-transport probes for the three diagnostic observer copies.

Exercises source-extracted oracle blocks before frontend/model comparison.
Fake oracle output is apparatus evidence only, never Go conformance evidence.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def main():
    env = dict(os.environ, GO111MODULE="off", GOCACHE=str(ROOT / "artifacts/go-build-cache"))
    scratch = Path(tempfile.mkdtemp(prefix="observer-tools-", dir=env.get("TMPDIR")))
    print(f"Diagnostic observer scratch: {scratch}", flush=True)
    harness = scratch / "coverageharness"
    subprocess.run(["go", "build", "-o", str(harness), "./tools/coverageharness"], cwd=ROOT, env=env, check=True)
    files = [ROOT / "scripts" / name for name in ["membership-sampling", "gotest-triage", "cedar-census"]]
    for path in [*files, Path(__file__), *sorted(ROOT.glob("tools/coverageharness/*.go"))]:
        print(hashlib.sha256(path.read_bytes()).hexdigest(), path.relative_to(ROOT), flush=True)
    fakebin = scratch / "fakebin"
    fakebin.mkdir()
    go = fakebin / "go"
    go.write_text("#!/usr/bin/env python3\nimport os,sys\nfrom pathlib import Path\n"
                  "sys.stdout.buffer.write(Path(os.environ['PROBE_STDOUT']).read_bytes())\n"
                  "sys.stderr.buffer.write(Path(os.environ['PROBE_STDERR']).read_bytes())\n"
                  "sys.exit(int(os.environ['PROBE_RC']))\n")
    go.chmod(0o755)
    trace = b"\n\ngoroutine 1 [running]:\nmain.main()\nexit status 2\n"
    ok = b'{"schema":"golean-observation-v1","status":"ok","values":[]}'
    failure = False
    for path in files:
        text = path.read_text()
        functions = []
        for name in ["one_line", "json_string_literal"]:
            match = re.search(rf"^{name}\(\) \{{.*?^\}}", text, re.M | re.S)
            if match:
                # one_line can be one line; do not swallow later definitions.
                first = text[text.index(name + "() {"):].splitlines()[0]
                functions.append(first if first.endswith("}") else match.group())
        if path.name == "membership-sampling":
            match = re.search(r"^oracle\(\) \{.*?^\}", text, re.M | re.S)
            if not match: raise SystemExit("missing diagnostic oracle function")
            code = match.group() + '\noracle "$dir" ""\n'
        else:
            start = "  # Expected Go-side output" if path.name == "gotest-triage" else "  # --- Go oracle ("
            stop = "  # --- Frontend" if path.name == "gotest-triage" else "  # --- Machine"
            begin = text.index(start)
            end = text.index(stop, begin)
            code = "probe() {\n" + text[begin:end] + '\nprintf "%s" "$go_obs"\n}\nprobe\n'
        script = scratch / (path.name + ".sh")
        script.write_text("set -uo pipefail\n" + "\n".join(functions) + "\n" + code)
        probes = [
            ("panic-controls", b"", b"panic: a\x00\x01\t\r" + trace, 1, b"", {"message":"a\x00\x01\t\r","output":""}),
            ("panic-prefix", b"", b"out\x00\x01\n" + b"panic: a\x00\n\tsecond" + trace, 1, b"", {"message":"a\x00","output":"out\x00\x01\n"}),
            ("invalid-utf8", b"", b"panic: a\xff" + trace, 1, b"", "UTF-8"),
            ("stdout-marker", b"panic: a" + trace, b"", 1, b"", "UNCLASSIFIED" if path.name == "membership-sampling" else "INFRA"),
            ("success", ok if path.name == "membership-sampling" else b"", b"", 0, b"", {"status":"ok","output":""}),
            ("nul-success", b"\x00" + (ok if path.name == "membership-sampling" else b""), b"", 0, b"", "UNCLASSIFIED" if path.name == "membership-sampling" else "INFRA"),
        ]
        if path.name == "gotest-triage":
            probes += [
                ("lf-not-empty", b"\n", b"", 0, b"", "INFRA"),
                ("crlf-normalized", b"a\r\n", b"", 0, b"a\n", {"status":"ok","output":""}),
                ("output-controls", b"", b"a\x00\x01\n", 0, b"a\x00\x01\n", {"status":"ok","output":"a\x00\x01\n"}),
            ]
        for label, stdout, stderr, rc, expected_file, expected in probes:
            case = scratch / (path.name + "-" + label)
            case.mkdir()
            (case / "stdout").write_bytes(stdout)
            (case / "stderr").write_bytes(stderr)
            (case / "subject.out").write_bytes(expected_file)
            probe_env = dict(env, PATH=str(fakebin) + os.pathsep + env["PATH"], HARNESS_BIN=str(harness),
                             GO_BUILD_CACHE=env["GOCACHE"], GO_TIMEOUT="10", PROBE_STDOUT=str(case / "stdout"),
                             PROBE_STDERR=str(case / "stderr"), PROBE_RC=str(rc), dir=str(case),
                             src=str(case / "subject.go"), rel="subject.go", name="subject", kind="driver")
            result = subprocess.run(["bash", str(script)], cwd=ROOT, env=probe_env, capture_output=True, timeout=30)
            (case / "result.stdout").write_bytes(result.stdout)
            (case / "result.stderr").write_bytes(result.stderr)
            try:
                if isinstance(expected, dict):
                    got = json.loads(result.stdout)
                    good = result.returncode == 0 and all(got.get(k) == v for k,v in expected.items())
                else:
                    good = expected.encode() in result.stdout
            except (ValueError, UnicodeDecodeError):
                good = False
            good = good and b"ignored null byte" not in result.stderr
            if not good:
                failure = True
                print(f"FAIL {path.name}/{label}: exit={result.returncode} stdout={result.stdout!r} stderr={result.stderr!r}", flush=True)
            else:
                print(f"PASS {path.name}/{label}", flush=True)
        # Independent real-Go byte observations through each diagnostic path.
        # These exercise the actual process/runtime report; they are still
        # observer controls, not a full tool census or model conformance run.
        for label, body, expected in [
            ("native-panic", r'print("out\x00\x01\n"); panic("a\x00\x01\t\r\nsecond")',
             {"message":"a\x00\x01\t\r","output":"out\x00\x01\n"}),
            ("native-invalid-utf8", r'panic("a\xff")', "UTF-8"),
            ("native-nul-success", r'print("\x00")', "UNCLASSIFIED" if path.name == "membership-sampling" else "INFRA"),
        ]:
            case = scratch / (path.name + "-" + label)
            case.mkdir()
            (case / "main.go").write_text("package main\nfunc main() { " + body + " }\n")
            native_env = dict(env, HARNESS_BIN=str(harness), GO_BUILD_CACHE=env["GOCACHE"], GO_TIMEOUT="10",
                              dir=str(case), src=str(case / "subject.go"), rel="subject.go", name="subject", kind="driver")
            result = subprocess.run(["bash", str(script)], cwd=ROOT, env=native_env, capture_output=True, timeout=30)
            (case / "result.stdout").write_bytes(result.stdout)
            (case / "result.stderr").write_bytes(result.stderr)
            try:
                if isinstance(expected, dict):
                    got = json.loads(result.stdout)
                    good = result.returncode == 0 and all(got.get(k) == v for k,v in expected.items())
                else:
                    good = expected.encode() in result.stdout
            except (ValueError, UnicodeDecodeError):
                good = False
            if not good or b"ignored null byte" in result.stderr:
                failure = True
                print(f"FAIL {path.name}/{label}: exit={result.returncode} stdout={result.stdout!r} stderr={result.stderr!r}", flush=True)
            else:
                print(f"PASS {path.name}/{label}", flush=True)
    raise SystemExit(1 if failure else 0)


if __name__ == "__main__":
    main()
