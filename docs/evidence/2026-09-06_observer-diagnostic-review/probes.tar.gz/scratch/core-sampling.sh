set -uo pipefail
run_with_timeout() {
  local seconds="$1"
  shift
  perl -e 'my $t = shift @ARGV; my $pid = fork(); die "fork failed\n" unless defined $pid; if ($pid == 0) { exec @ARGV; exit 127 } $SIG{ALRM} = sub { print STDERR "run_with_timeout: TIMED OUT after ${t}s — killing: @ARGV\n"; kill "TERM", $pid; select undef, undef, undef, 1; kill "KILL", $pid; exit 124 }; alarm $t; waitpid $pid, 0; my $s = $?; exit($s == -1 ? 127 : ($s & 127 ? 128 + ($s & 127) : $s >> 8));' "$seconds" "$@"
}
go_run_oracle() {
  # Race-expectation cases build with -race (the TSan second oracle);
  # everything else runs plain — except that membership SAMPLING may
  # force a -race build ($1 = race): the slice-4 doctrine update makes
  # -race a default membership sample source (its runtime perturbs
  # scheduling — plain go run is a point-mass on schedule-dependent
  # shapes; probes: 0/700 vs 6/6 orderings). The two oracle MODES still
  # never mix in one deadlock case: -race suppresses the deadlock
  # detector (ground-truth note §5), and membership excludes deadlock.
  local race_flag=()
  if [[ "$expected_status" == "race" || "${1:-}" == "race" ]]; then
    race_flag=(-race)
  fi
  # Multi-package cases (raft W1.1): the harness assembled the case's
  # local packages under <go_run_dir>/gopath; hand that tree (ABSOLUTE —
  # GOPATH rejects relative entries) to Go's own resolution. Absent for
  # single-package cases, whose environment stays byte-identical.
  local gopath_env=()
  if [[ -d "$go_run_dir/gopath" ]]; then
    gopath_env=(GOPATH="$(cd "$go_run_dir/gopath" && pwd -P)")
  fi
  # THE FD SPLIT (stdlib slice 3): stdout (the harness's observation JSON)
  # and stderr (the program's print output, then gc's abort report, then
  # go run's `exit status N` trailer) are captured to SEPARATE files —
  # the `output` field is the program's stderr prefix, recovered
  # fail-closed by the harness's --split-stderr mode (attach_output). The
  # files never travel through shell substitution as raw bytes: Bash
  # drops NUL. Callers classify stderr directly and ask coverageharness
  # to encode messages/output or validate stdout before shell transport.
  # The run's exit code is returned unchanged.
  local rc=0
  # GOFLAGS is SCRUBBED (audit fix round C3, 2026-09-05): an inherited
  # `GOFLAGS=-x`/`-v` writes build chatter to the child's stderr, which
  # is now a COMPARED channel (the `output` field), like GODEBUG already
  # was pinned for panicnil.
  run_with_timeout "$GO_TIMEOUT_SECONDS" env GO111MODULE=off GOFLAGS= GODEBUG=panicnil=0 GOCACHE="$GO_BUILD_CACHE" \
    ${gopath_env[@]+"${gopath_env[@]}"} \
    bash -c 'cd "$1" && shift && exec go run "$@" .' go-run-oracle "$go_run_dir" ${race_flag[@]+"${race_flag[@]}"} \
    > "$go_run_dir/oracle.stdout" 2> "$go_run_dir/oracle.stderr" || rc=$?
  return "$rc"
}
go_diagnostics() {
  printf 'stdout='
  "$HARNESS_BIN" --quote-file "$go_run_dir/oracle.stdout"
  printf ' stderr='
  "$HARNESS_BIN" --quote-file "$go_run_dir/oracle.stderr"
}
membership_go_observation() {
  local out rc=0 valid_rc=0 go_cause valid_cause
  go_run_oracle "${1:-}" || rc=$?
  out="$(go_diagnostics)"
  if go_cause="$(undecided_cause "$rc" "go run oracle" "$GO_TIMEOUT_SECONDS" GO_TIMEOUT_SECONDS)"; then
    # Named before any status reading: a killed oracle (wall clock,
    # SIGKILL/SIGTERM, any non-verdict code) is no sample, and its
    # partial output used to surface as "status outside the declared
    # set" / "expected Go panic, got: …".
    printf 'go sample: %s — no sample produced (not a status verdict); captured output: %s' "$go_cause" "$out"
    return 1
  fi
  if [[ "$rc" -eq 0 ]]; then
    if ! member_status_allowed ok; then
      printf 'go sample: declared status set (%s) excludes ok, but Go exited successfully: %s' "$statuses" "$out"
      return 1
    fi
    if ! out="$("$HARNESS_BIN" --read-observation "$go_run_dir/oracle.stdout" 2>"$go_run_dir/oracle.read.err")"; then
      printf 'go sample: %s: %s' "$(cat "$go_run_dir/oracle.read.err")" "$(go_diagnostics)"
      return 1
    fi
    # The `output` field (stdlib slice 3): the sample's fd-2 bytes, split
    # fail-closed like the strict lane's (attach_output's rule, inlined —
    # this function reports through its stdout, not report_fail).
    local lit split_rc=0
    lit="$("$HARNESS_BIN" --split-stderr "$go_run_dir/oracle.stderr" --expected-status ok 2>"$go_run_dir/oracle.split.err")" || split_rc=$?
    if [[ "$split_rc" -ne 0 ]]; then
      printf 'go sample: the oracle stderr could not be split into program output (harness exit %s): %s' "$split_rc" "$(one_line "$(cat "$go_run_dir/oracle.split.err")")"
      return 1
    fi
    out="{\"output\":$lit,${out#\{}"
    obs_eq "$out" "$out"; valid_rc=$?
    # Self-comparison: exit 2 IS the decision (see the strict lane's
    # validity check) — accurate wording + the decode message.
    if [[ "$valid_rc" -eq 2 ]]; then
      printf 'go sample is not a valid observation (comparator said: %s): %s' "$(one_line "$OBS_EQ_STDERR")" "$out"
      return 1
    elif valid_cause="$(obs_eq_cause "$valid_rc")"; then
      printf 'go sample: %s validating the sample — validity NOT decided: %s' "$valid_cause" "$out"
      return 1
    elif [[ "$valid_rc" -ne 0 ]]; then
      printf 'go sample is not a valid observation: %s' "$out"
      return 1
    fi
    if [[ "$out" != *"\"status\":\"ok\""* ]]; then
      printf 'go sample: expected an ok observation from a successful run, got %s' "$out"
      return 1
    fi
    printf '%s' "$out"
    return 0
  fi
  if grep -aqF -- 'panic:' "$go_run_dir/oracle.stderr" && member_status_allowed panic; then
    if [[ "$expected_status" == "panic" ]] && ! grep -aqF -- "$expected_reason" "$go_run_dir/oracle.stderr"; then
      printf 'go sample: Go panic did not contain expected reason %s: %s' "$expected_reason" "$out"
      return 1
    fi
    local escaped
    if ! escaped="$("$HARNESS_BIN" --abort-message "$go_run_dir/oracle.stderr" --expected-status panic 2>"$go_run_dir/oracle.message.err")"; then
      printf 'go sample: could not extract Go panic message: %s; %s' "$(cat "$go_run_dir/oracle.message.err")" "$out"
      return 1
    fi
    local lit split_rc=0
    lit="$("$HARNESS_BIN" --split-stderr "$go_run_dir/oracle.stderr" --expected-status panic 2>"$go_run_dir/oracle.split.err")" || split_rc=$?
    if [[ "$split_rc" -ne 0 ]]; then
      printf 'go sample: the oracle stderr could not be split into program output + panic report (harness exit %s): %s' "$split_rc" "$(one_line "$(cat "$go_run_dir/oracle.split.err")")"
      return 1
    fi
    printf '{"message":%s,"output":%s,"schema":"golean-observation-v1","status":"panic"}' "$escaped" "$lit"
    return 0
  fi
  if [[ "$expected_status" == "panic" ]]; then
    printf 'go sample: expected Go panic, got: %s' "$out"
    return 1
  fi
  printf 'go sample run failed (status outside the declared set %s): %s' "$statuses" "$out"
  return 1
}
member_status_allowed() {
  [[ "+$statuses+" == *"+$1+"* ]]
}
undecided_cause() {
  local rc="$1" what="$2" seconds="$3" knob="$4"
  case "$rc" in
    0|1) return 1 ;;
    124) printf '%s TIMED OUT after %ss (%s)' "$what" "$seconds" "$knob" ;;
    *)   signal_cause "$rc" "$what" || printf '%s failed with exit %s (did not decide)' "$what" "$rc" ;;
  esac
}
signal_cause() {
  local rc="$1" what="$2"
  case "$rc" in
    137) printf '%s KILLED (exit 137 — SIGKILL: cgroup/OOM or an external kill; did not decide)' "$what" ;;
    143) printf '%s KILLED (exit 143 — SIGTERM: an external kill; did not decide)' "$what" ;;
    *)   if (( rc > 128 && rc <= 192 )); then
           printf '%s KILLED (exit %s — died on signal %s; did not decide)' "$what" "$rc" "$((rc - 128))"
         else
           return 1
         fi ;;
  esac
}
obs_eq_cause() {
  local rc="$1" said
  said="$(one_line "$OBS_EQ_STDERR")"
  case "$rc" in
    0|1) return 1 ;;
    2)   printf 'observation-eq could not decode the observation (exit 2 — did not decide; comparator said: %s)' "$said" ;;
    124) undecided_cause 124 observation-eq "$LEAN_TIMEOUT_SECONDS" LEAN_TIMEOUT_SECONDS ;;
    *)   undecided_cause "$rc" observation-eq "$LEAN_TIMEOUT_SECONDS" LEAN_TIMEOUT_SECONDS
         if [[ -n "$said" ]]; then printf ' (comparator said: %s)' "$said"; fi ;;
  esac
  # The status is the CLASSIFICATION, never the last printf's: a SIGKILL
  # leaves an empty stderr, and `[[ -n … ]] && printf` as the last
  # command returned 1 — the kill read as a verdict (caught red by T7).
  return 0
}
obs_eq() {
  local rc=0
  OBS_EQ_STDERR="$(lean observation-eq --left "$1" --right "$2" 2>&1 >/dev/null)" || rc=$?
  return "$rc"
}
lean() {
  run_with_timeout "$LEAN_TIMEOUT_SECONDS" "$GOLEAN_BIN" "$@"
}
one_line() {
  local value="$1"
  value="${value//$'\t'/ }"
  value="${value//$'\r'/\\r}"
  value="${value//$'\n'/\\n}"
  printf '%s' "$value"
}
attach_output() {
  local lit rc=0
  lit="$("$HARNESS_BIN" --split-stderr "$go_run_dir/oracle.stderr" --expected-status "$1" 2>"$go_run_dir/oracle.split.err")" || rc=$?
  if [[ "$rc" -ne 0 ]]; then
    report_fail "$id" "$features" "go-observation" "the oracle's stderr could not be split into program output + abort report (harness exit $rc): $(one_line "$(cat "$go_run_dir/oracle.split.err")")"
    return 1
  fi
  go_observation="{\"output\":$lit,${go_observation#\{}"
}
membership_go_observation "$PROBE_MODE"
