set -uo pipefail
one_line() { local v="$1"; v="${v//$'\t'/ }"; v="${v//$'\r'/\\r}"; v="${v//$'\n'/\\n}"; printf '%s' "$v"; }
probe() {
  # --- Go oracle (functional drivers only) ------------------------------
  local go_out go_rc go_status go_obs go_msg
  (cd "$dir" && timeout "$GO_TIMEOUT" env GO111MODULE=off GOFLAGS= GODEBUG=panicnil=0 GOCACHE="$GO_BUILD_CACHE" GOPATH="$dir/gopath" go run . > oracle.stdout 2> oracle.stderr)
  go_rc=$?
  cat "$dir/oracle.stdout" "$dir/oracle.stderr" > "$dir/go.out"
  go_out="stdout=$("$HARNESS_BIN" --quote-file "$dir/oracle.stdout") stderr=$("$HARNESS_BIN" --quote-file "$dir/oracle.stderr")"
  if [[ "$go_rc" -eq 124 ]]; then
    printf 'INFRA\t%s\t%s\t%s\n' "$name" "$kind" "go run timed out after ${GO_TIMEOUT}s"; return
  elif [[ "$go_rc" -eq 0 ]]; then
    go_status="ok"; go_obs='{"output":"","schema":"golean-observation-v1","status":"ok","values":[]}'
    if [[ -s "$dir/oracle.stdout" || -s "$dir/oracle.stderr" ]]; then
      printf 'INFRA\t%s\t%s\t%s\n' "$name" "$kind" "driver printed on success (drivers must be silent): $(one_line "${go_out:0:200}")"; return
    fi
  elif [[ "$go_rc" -ne 1 ]]; then
    printf 'INFRA\t%s\t%s\t%s\n' "$name" "$kind" "go run exited $go_rc without a runtime verdict: $(one_line "${go_out:0:240}")"; return
  elif grep -aqF -- 'fatal error: all goroutines are asleep - deadlock!' "$dir/oracle.stderr"; then
    go_status="deadlock"; go_obs='{"message":"all goroutines are asleep - deadlock!","schema":"golean-observation-v1","status":"deadlock"}'
  elif grep -aqF -- 'panic:' "$dir/oracle.stderr"; then
    go_status="panic"
    if ! go_msg="$("$HARNESS_BIN" --abort-message "$dir/oracle.stderr" --expected-status panic 2>"$dir/oracle.message.err")"; then
      printf 'INFRA\t%s\t%s\t%s\n' "$name" "$kind" "oracle panic message refused: $(cat "$dir/oracle.message.err")"; return
    fi
    go_obs="{\"message\":$go_msg,\"schema\":\"golean-observation-v1\",\"status\":\"panic\"}"
  else
    printf 'INFRA\t%s\t%s\t%s\n' "$name" "$kind" "go run exited $go_rc without panic: $(one_line "${go_out:0:240}")"; return
  fi
  # Preserve fd-2 program output before an abort, just as the core observer
  # does; no empty-output fabrication and no raw bytes in shell variables.
  if [[ "$go_status" != "ok" ]]; then
    local out_lit
    if ! out_lit="$("$HARNESS_BIN" --split-stderr "$dir/oracle.stderr" --expected-status "$go_status" 2>"$dir/oracle.split.err")"; then
      printf 'INFRA\t%s\t%s\t%s\n' "$name" "$kind" "oracle stderr split refused: $(cat "$dir/oracle.split.err")"; return
    fi
    go_obs="{\"output\":$out_lit,${go_obs#\{}"
  fi

printf "%s" "$go_obs"
}
probe
