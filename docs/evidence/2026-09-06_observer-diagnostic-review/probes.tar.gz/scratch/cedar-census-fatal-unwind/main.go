package main
import "sync"
func main(){ var m sync.Mutex; defer m.Unlock(); panic("original") }
