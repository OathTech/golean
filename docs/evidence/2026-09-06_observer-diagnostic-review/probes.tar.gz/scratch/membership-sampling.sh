set -uo pipefail

oracle() {  # $1 = harness dir, $2 = "" | race
  local dir="$1" mode="$2" out rc=0 lit split_rc=0
  local race=()
  [[ "$mode" == "race" ]] && race=(-race)
  # Multi-package cases (raft W1.1): the harness assembled the case's local
  # packages under <dir>/gopath — hand that tree to Go's resolution exactly
  # as scripts/diff-coverage's go_run_oracle does (ABSOLUTE path).
  local gopath_env=()
  if [[ -d "$dir/gopath" ]]; then
    gopath_env=(GOPATH="$(cd "$dir/gopath" && pwd -P)")
  fi
  # stdout/stderr captured SEPARATELY (stdlib slice 3): the `output`
  # observation field is the program's fd-2 prefix, split fail-closed by
  # the harness's --split-stderr mode exactly as scripts/diff-coverage does.
  (cd "$dir" && env GO111MODULE=off GOFLAGS= GODEBUG=panicnil=0 GOCACHE="$GO_BUILD_CACHE" ${gopath_env[@]+"${gopath_env[@]}"} go run ${race[@]+"${race[@]}"} . > oracle.stdout 2> oracle.stderr) || rc=$?
  out="stdout=$("$HARNESS_BIN" --quote-file "$dir/oracle.stdout") stderr=$("$HARNESS_BIN" --quote-file "$dir/oracle.stderr")"
  if [[ "$rc" -eq 0 ]]; then
    if ! out="$("$HARNESS_BIN" --read-observation "$dir/oracle.stdout" 2>"$dir/oracle.read.err")"; then
      printf 'UNCLASSIFIED: %s' "$(cat "$dir/oracle.read.err")"; return 1
    fi
    if [[ "$out" == *'"status":"ok"'* ]]; then
      lit="$("$HARNESS_BIN" --split-stderr "$dir/oracle.stderr" --expected-status ok 2>"$dir/oracle.split.err")" || split_rc=$?
      if [[ "$split_rc" -ne 0 ]]; then printf 'UNCLASSIFIED (stderr split failed, exit %s): %s' "$split_rc" "$(head -c 300 "$dir/oracle.split.err")"; return 1; fi
      printf '{"output":%s,%s' "$lit" "${out#\{}"; return 0
    fi
    printf 'UNCLASSIFIED: %s' "$out"; return 1
  fi
  if [[ "$rc" -eq 1 ]] && grep -aqF -- 'panic:' "$dir/oracle.stderr"; then
    local msg
    if ! msg="$("$HARNESS_BIN" --abort-message "$dir/oracle.stderr" --expected-status panic 2>"$dir/oracle.message.err")"; then
      printf 'UNCLASSIFIED: %s' "$(cat "$dir/oracle.message.err")"; return 1
    fi
    lit="$("$HARNESS_BIN" --split-stderr "$dir/oracle.stderr" --expected-status panic 2>"$dir/oracle.split.err")" || split_rc=$?
    if [[ "$split_rc" -ne 0 ]]; then printf 'UNCLASSIFIED (stderr split failed, exit %s): %s' "$split_rc" "$(head -c 300 "$dir/oracle.split.err")"; return 1; fi
    printf '{"message":%s,"output":%s,"schema":"golean-observation-v1","status":"panic"}' "$msg" "$lit"
    return 0
  fi
  printf 'UNCLASSIFIED: %s' "$out"; return 1
}
oracle "$dir" ""
