package main
func WrongKind(){ panic(42) }
func main(){}
