package main

func arraySliceAlias() int {
	a := [3]int{1, 2, 3}
	s := a[1:3]
	s[0] = 9
	z := a[1] + len(s)*10 + cap(s)*100

	return z
}
