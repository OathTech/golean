package main

func arrayLenCap() int {
	a := [3]int{1, 2, 3}
	z := len(a) + cap(a)
	return z
}
